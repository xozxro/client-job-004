import time

import requests

import json

import tda
from discord_webhook import DiscordWebhook, DiscordEmbed
from tda import auth, client
import json

import data

import traceback

from tda.orders.common import Duration, Session
from tda.orders.options import OptionSymbol, option_buy_to_open_limit

api_key = data.apiKey
redirect_uri = 'https://127.0.0.1'
token_path = 'tokens.json'


def getOptionsPrice(stock='SPY', key='AJBGODZYFXUOR5WID9IJNJCMZTDTJAAR', exp='', side='', strike='', sell=False, full=''):
    try:
        if stock.lower() == 'spx.x': stock = '$spx.x'

        base_url = 'https://api.tdameritrade.com/v1/marketdata/chains?&symbol={stock_ticker}'

        endpoint = base_url.format(stock_ticker=stock.upper())

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:77.0) Gecko/20190101 Firefox/77.0',
        }

        if stock.lower() == 'spx.x': stock = '$spx.x'

        expiration = exp.split('/')

        try:
            if len(expiration[0]) == 1: expiration[0] = '0' + expiration[0]
            if len(expiration[1]) == 1: expiration[1] = '0' + expiration[1]
            date = expiration[0] + expiration[1] + '22'
            exp = expiration[0] + '/' + expiration[1]
        except:
            pass

        side = side.upper()

        strike = str(strike).replace('.0','')

        symbol = stock.upper() + '_' + str(date) + side + str(strike)

        if side.lower() == 'c':
            type = 'CALL'
        else:
            type = 'PUT'

        # print(strike)
        # print('2022-' + exp.replace('/','-'))
        # print(type)

        try:
            page = requests.get(url=endpoint,
                                params={'apikey': 'SBSNVCPADGORCRTXFI8TJAGTXC0Q2ZGT', 'contractType': type, 'strike': strike,
                                        'toDate': '2022-' + exp.replace('/', '-')}, headers=headers)
        except:

            try:
                page = requests.get(url=endpoint,
                                    params={'apikey': 'SBSNVCPADGORCRTXFI8TJAGTXC0Q2ZGT', 'contractType': type, 'strike': strike}, headers=headers)

            except:

                try:
                    page = requests.get(url=endpoint,
                                        params={'apikey': 'SBSNVCPADGORCRTXFI8TJAGTXC0Q2ZGT', 'strike': strike}, headers=headers)

                except:

                    page = requests.get(url=endpoint,
                                        params={'apikey': 'SBSNVCPADGORCRTXFI8TJAGTXC0Q2ZGT'}, headers=headers)

        # print('strike: ' + strike)

        if 'FAILED' in str(page.content):

            page = requests.get(url=endpoint,
                                        params={'apikey': 'SBSNVCPADGORCRTXFI8TJAGTXC0Q2ZGT'}, headers=headers)

        # print('strike: ' + side)

        print(page.content)

        if type == 'PUT' or side.lower() == 'p':
            chain = json.loads(page.content)
            chain = chain['putExpDateMap']

        if type == 'CALL' or side.lower() == 'c':
            chain = json.loads(page.content)
            chain = chain['callExpDateMap']


        exp = exp.split('/')

        date = '2022-' + exp[0] + '-' + exp[1]

        try:
            for x in chain:

                # print(x)

                if date in x:

                    if strike != '':

                        try:

                            if strike not in [y for y in chain[x]]:

                                strikeList = [y for y in chain[x]]
                                for strike_ in chain[x]:

                                    try: lastStrike = strikeList[chain[x][strike].index() - 1]
                                    except: lastStrike = strike_
                                    try: nextStrike = strikeList[chain[x][strike].index() + 1]
                                    except: nextSTrike = strike_

                                    if float(lastStrike) < float(strike):
                                        strike = strike_

                                        if float(strike_) > float(strike): break

                            if full == 'str':  return '(' + str(chain[x][str(float(strike))][0]['bid']) + ', ' + str(chain[x][str(float(strike))][0]['ask']) + ')'
                            if full:
                                return chain[x][str(float(strike))][0]['bid'], chain[x][str(float(strike))][0]['ask']

                            if sell:
                                return chain[x][str(float(strike))][0]['bid']
                            elif sell is False:
                                return chain[x][str(float(strike))][0]['ask']
                            break

                        except Exception as exception:
                            traceback.print_exc()
                            for y in chain[x].keys():
                                if strike in y:
                                    try:
                                        if full == 'str': return '(' + str(chain[x][y][0]['bid']) + ', ' + str(chain[x][y][0]['ask']) + ')'
                                        if full:
                                            return chain[x][y][0]['bid'], chain[x][y][0]['ask']
                                        if sell:
                                            return chain[x][y][0]['bid']
                                        elif sell is False:
                                            return chain[x][y][0]['ask']
                                    except:

                                        pass
                            break

                    else:

                        return float(expOptions)

        except Exception as exception:



            traceback.print_exc()

            # print(page)
            # try:
            # print(json.loads(page.content))
            # except:
            # pass

    except Exception as exception:
        traceback.print_exc()
