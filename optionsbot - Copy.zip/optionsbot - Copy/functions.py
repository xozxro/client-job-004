from multiprocessing.connection import wait
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import pickle
import os.path
import base64
import email
from bs4 import BeautifulSoup
import time
from discord_webhook import DiscordWebhook, DiscordEmbed
import traceback
import data
import random
from datetime import datetime


from optionChain import getOptionsChain
from getPrice import getOptionsPrice


def pushDiscordNotification(ticker,side,oneWeek,twoWeek,oneMonth,expirations,strike,price='',futurePrice='',action=''):
    
    newSide = side[-1]
    print(side)
    print(action)
    if action == 'SELL' or action == 'sell':
        color = 'eb3455'
        actionText = 'STC'
        try:
            if 'c' in side.lower() or side.lower() == 'sellc' or side.lower()[-1] == 'c':
                newSide = 'c'
            else: 
                newSide = 'p'
        except:
            if 'c' in side.lower():
                newSide = 'c'
            else:
                newSide = 'p'
    elif action == 'BUY' or action == 'buy':
        color = '00FFE4'
        actionText = 'BTO'
        if 'c' in side.lower() or side.lower() == 'c':
            newSide = 'c'
        else:
            newSide = 'p'
            
    print('becomes')
    print(newSide)
    print(actionText)
    
    if 'sell' in action.lower(): actionText = 'STC'
    if 'buy' in action.lower(): actionText = 'BTO'
    
    print('becomes')
    
    print(actionText)    
    if ticker.lower() == '/eth':
        
        webhook = DiscordWebhook(url='https://discord.com/api/webhooks/998947029600440442/O8HqDFNfpLpCV2SjK0KDMCo4GxxdgCTalli7d2NKtgfwx0zAStRCVpbrbMNN9PNPnFKX', username='Nyria', content='**crypto Alert @everyone**')   
        if side.lower() == 'p' or 'p' in side.lower() or 'longp' in side.lower(): 
            sideText = 'BEAR'
            directionText = 'SHORT'
        if side.lower() == 'c' or'c' in side.lower() or 'longc' in side.lower(): 
            sideText = 'BULL'
            directionText = 'LONG'     
        embed = DiscordEmbed(title='[ crypto ]', description=actionText + ' 1 ETH 3X ' + sideText + ' FUTURE @' + str(futurePrice), color=color)
        embed.add_embed_field(name='Symbol', value='/ETH')
        embed.add_embed_field(name='Underlying Price', value=str(price))
        embed.add_embed_field(name='Contract Price', value=str(futurePrice))
        embed.add_embed_field(name='Direction', value=directionText)
        webhook.add_embed(embed)
        response = webhook.execute()
     
        if data.cryptoBot:
            print('cryptobot is true')
            try:
                if futurePrice != '': price = float(futurePrice)
                if actionText == 'BTO' or 'bto' in actionText.lower(): 
                    cryptoBot.placeOrder('/ETH', 'BUY', futurePrice)
                else: 
                    cryptoBot.placeOrder('/ETH', 'SELL', futurePrice)
            except Exception as exception:
                print('#######################################')
                print('cryptobot error!')
                traceback.print_exc()
    
    
    elif ticker.lower() != '/eth':
        
        # IMPORTANT #
        # DONT PROCESS TICKER ALERTS AFTER 4PM EST #
        now = datetime.now()
        if int(now.strftime("%H")) >= 16 or int(now.strftime("%H")) < 9:
            print('[!] cant output stock data after 4PM or before 9AM.')
            return
        
        for url in data.webhooks:
            
            try:
                
                webhook = DiscordWebhook(url=url, username='Nyria', content='**oneWeek Alert @everyone**')
                embed = DiscordEmbed(title='[ oneWeek ]', description=actionText + ' 1 ' + ticker + ' ' + expirations[0] + ' ' + strike + newSide + ' @' + str(oneWeek['ask']), color=color)
                embed.add_embed_field(name='Ticker', value=ticker)
                embed.add_embed_field(name='Expiration', value=expirations[0])
                embed.add_embed_field(name='Strike', value=strike)
                embed.add_embed_field(name='Side', value=newSide)
                embed.add_embed_field(name='Underlying Price', value=str(price))
                try:
                    embed.add_embed_field(name='Contract Price', value=str(oneWeek['ask']))
                    try:
                        embed.add_embed_field(name='Current Price', value=getOptionsPrice(stock=ticker.lower().replace('$',''), exp=expirations[0], side=side, strike=strike, sell=False, full='str'))
                    except:
                        currentPrice = '(' + str(oneWeek['bid']) + ', ' + str(oneWeek['ask']) + ')'
                        embed.add_embed_field(name='Current Price', value=currentPrice)
                except:
                    pass
                webhook.add_embed(embed)
                response = webhook.execute()
                
            except:
                pass
                
            try:
                
                webhook = DiscordWebhook(url=url, username='Nyria', content='**twoWeek Alert @everyone**')
                embed = DiscordEmbed(title='[ twoWeek ]', description=actionText + ' 1 ' + ticker + ' ' + expirations[1] + ' ' + strike + side + ' @' + str(twoWeek['ask']), color=color)
                embed.add_embed_field(name='Ticker', value=ticker)
                embed.add_embed_field(name='Expiration', value=expirations[1])
                embed.add_embed_field(name='Strike', value=strike)
                embed.add_embed_field(name='Side', value=side)
                embed.add_embed_field(name='Underlying Price', value=str(price))
                try:
                    embed.add_embed_field(name='Contract Price', value=str(twoWeek['ask']))
                    try:
                        embed.add_embed_field(name='Current Price', value=getOptionsPrice(stock=ticker.lower().replace('$',''), exp=expirations[0], side=side, strike=strike, sell=False, full='str'))
                    except:
                        currentPrice = '(' + str(twoWeek['bid']) + ', ' + str(twoWeek['ask']) + ')'
                        embed.add_embed_field(name='Current Price', value=currentPrice)
                except:
                    pass
                webhook.add_embed(embed)
                response = webhook.execute()
                
            except:
                pass
            
            try:
                
                webhook = DiscordWebhook(url=url, username='Nyria', content='**oneMonth Alert @everyone**')
                embed = DiscordEmbed(title='[ oneMonth ]', description=actionText + ' 1 ' + ticker + ' ' + expirations[2] + ' ' + strike + side + ' @' + str(oneMonth['ask']), color=color)
                embed.add_embed_field(name='Ticker', value=ticker)
                embed.add_embed_field(name='Expiration', value=expirations[2])
                embed.add_embed_field(name='Strike', value=strike)
                embed.add_embed_field(name='Side', value=side)
                embed.add_embed_field(name='Underlying Price', value=str(price))
                try:
                    embed.add_embed_field(name='Contract Price', value=str(oneMonth['ask']))
                    try:
                        embed.add_embed_field(name='Current Price', value=getOptionsPrice(stock=ticker.lower().replace('$',''), exp=expirations[0], side=side, strike=strike, sell=False, full='str'))
                    except:
                        currentPrice = '(' + str(oneMonth['bid']) + ', ' + str(oneMonth['ask']) + ')'
                        embed.add_embed_field(name='Current Price', value=currentPrice)
                except:
                    pass
                webhook.add_embed(embed)
                response = webhook.execute()
                
            except:
                pass
    


def log(ticker,price,type,algo=''):
    
    try:
        time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with open('log.txt','a') as f:
            f.write('\n')
            f.write(time + '  |  ' + ticker + ' | ' + type.upper() + ' | ' + str(price) + ' | ALGO=[' + algo + ']')
            f.close()
        return
    except Exception as exception:
        traceback.print_exc()



class Tracker():
    
    def __init__(self):
        
        self.mainDict = {}
        
        self.oneMin = False
        self.fiveMin = False
        self.fifteenMin = False
        self.thirtyMin = False
        self.oneDay = False
        self.oneMinSell = False
        self.fiveMinSell = False
        self.fifteenMinSell = False
        self.thirtyMinSell = False
        self.oneDaySell = False
        self.cond1 = False
        self.cond2 = False
        self.purchased = False
        self.purchasedPuts = False
        
    def loadTicker(self,saveTicker):
        
        self.saveTicker = saveTicker
        
        try:
            
            test = self.mainDict[saveTicker]
            
            self.oneMin = self.mainDict[saveTicker]['oneMin']
            self.fiveMin = self.mainDict[saveTicker]['fiveMin']
            self.fifteenMin = self.mainDict[saveTicker]['fifteenMin']
            self.thirtyMin = self.mainDict[saveTicker]['thirtyMin']
            self.oneDay = self.mainDict[saveTicker]['oneDay']
            self.oneMinSell = self.mainDict[saveTicker]['oneMinSell']
            self.fiveMinSell = self.mainDict[saveTicker]['fiveMinSell']
            self.fifteenMinSell = self.mainDict[saveTicker]['fifteenMinSell']
            self.thirtyMinSell = self.mainDict[saveTicker]['thirtyMinSell']
            self.oneDaySell = self.mainDict[saveTicker]['oneDaySell']
            self.cond1 = self.mainDict[saveTicker]['cond1']
            self.cond2 = self.mainDict[saveTicker]['cond2']
            self.purchased = self.mainDict[saveTicker]['purchased']
            self.purchasedPuts = self.mainDict[saveTicker]['purchasedPuts']
            
        except:
            
            self.oneMin = False
            self.fiveMin = False
            self.fifteenMin = False
            self.thirtyMin = False
            self.oneDay = False
            self.oneMinSell = False
            self.fiveMinSell = False
            self.fifteenMinSell = False
            self.thirtyMinSell = False
            self.oneDaySell = False
            if '/' in saveTicker:
                self.cond1 = 0
                self.cond2 = 0
            else:
                self.cond1 = False
                self.cond2 = False
            self.purchased = False
            self.purchasedPuts = False
            
            self.mainDict[saveTicker] = {}
            
            self.mainDict[self.saveTicker]['oneMin'] = self.oneMin
            self.mainDict[self.saveTicker]['fiveMin'] = self.fiveMin
            self.mainDict[self.saveTicker]['fifteenMin'] = self.fifteenMin
            self.mainDict[self.saveTicker]['thirtyMin'] = self.thirtyMin
            self.mainDict[self.saveTicker]['oneDay'] = self.oneDay
            self.mainDict[self.saveTicker]['oneMinSell'] = self.oneMinSell
            self.mainDict[self.saveTicker]['fiveMinSell'] = self.fiveMinSell
            self.mainDict[self.saveTicker]['fifteenMinSell'] = self.fifteenMinSell
            self.mainDict[self.saveTicker]['thirtyMinSell'] = self.thirtyMinSell
            self.mainDict[self.saveTicker]['oneDaySell'] = self.oneDaySell
            self.mainDict[self.saveTicker]['cond1'] = self.cond1
            self.mainDict[self.saveTicker]['cond2'] = self.cond2
            self.mainDict[self.saveTicker]['purchased'] = self.purchased
            self.mainDict[self.saveTicker]['purchasedPuts'] = self.purchasedPuts
            
        
    def pushTicker(self):
                
        self.mainDict[self.saveTicker]['oneMin'] = self.oneMin
        self.mainDict[self.saveTicker]['fiveMin'] = self.fiveMin
        self.mainDict[self.saveTicker]['fifteenMin'] = self.fifteenMin
        self.mainDict[self.saveTicker]['thirtyMin'] = self.thirtyMin
        self.mainDict[self.saveTicker]['oneDay'] = self.oneDay
        self.mainDict[self.saveTicker]['oneMinSell'] = self.oneMinSell
        self.mainDict[self.saveTicker]['fiveMinSell'] = self.fiveMinSell
        self.mainDict[self.saveTicker]['fifteenMinSell'] = self.fifteenMinSell
        self.mainDict[self.saveTicker]['thirtyMinSell'] = self.thirtyMinSell
        self.mainDict[self.saveTicker]['oneDaySell'] = self.oneDaySell
        self.mainDict[self.saveTicker]['cond1'] = self.cond1
        self.mainDict[self.saveTicker]['cond2'] = self.cond2
        self.mainDict[self.saveTicker]['purchased'] = self.purchased
        self.mainDict[self.saveTicker]['purchasedPuts'] = self.purchasedPuts
        
        self.oneMin = False
        self.fiveMin = False
        self.fifteenMin = False
        self.thirtyMin = False
        self.oneDay = False
        self.oneMinSell = False
        self.fiveMinSell = False
        self.fifteenMinSell = False
        self.thirtyMinSell = False
        self.oneDaySell = False
        self.cond1 = False
        self.cond2 = False
        self.purchased = False
        self.purchasedPuts = False
            
        self.saveTicker = ''
    

class signalReader:

    # Define the SCOPES. If modifying it, delete the token.pickle file.
    def __init__(self):

        self.SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

        self.doneAlerts = []

    def getAlert(self,account):

        if account == 'a':
            
            self.creds = None
            if os.path.exists('token.pickle'):
                # Read the token from the file and store it in the variable creds
                with open('token.pickle', 'rb') as token:
                    self.creds = pickle.load(token)

            # If credentials are not available or are invalid, ask the user to log in.
            if not self.creds or not self.creds.valid:
                if self.creds and self.creds.expired and self.creds.refresh_token:
                    self.creds.refresh(Request())
                else:
                    self.flow = InstalledAppFlow.from_client_secrets_file('tokensa.json', self.SCOPES)
                    self.creds = self.flow.run_local_server(port=0)

                # Save the access token in token.pickle file for the next run
                with open('token.pickle', 'wb') as token:
                    pickle.dump(self.creds, token)

            # Connect to the Gmail API
            self.service = build('gmail', 'v1', credentials=self.creds)
            
            
            # request a list of all the messages
            working = False
            cnt = 0
            while working is False:
                try:
                    self.result = self.service.users().messages().list(userId='me').execute()
                    working = True
                except Exception as exception:
                    cnt += 1
                    traceback.print_exc()
                    print('[!] rate limited.. pausing for 5')
                    time.sleep(5)
                if cnt == 2:
                    return 'RATELIMIT'
                
                
            # We can also pass maxResults to get any number of emails. Like this:
            # result = service.users().messages().list(maxResults=200, userId='me').execute()
            self.messages = self.result.get('messages')[:30][::-1]

            # messages is a list of dictionaries where each dictionary contains a message id.

            # iterate through all the messages
            for msg in self.messages:
                # Get the message from its id

                working = False
                cnt = 0
                while working is False:
                    try:
                        self.txt = self.service.users().messages().get(userId='me', id=msg['id']).execute()
                        working = True
                    except Exception as exception:
                        cnt += 1
                        traceback.print_exc()
                        print('[!] rate limited.. pausing for 5')
                        time.sleep(5)
                    if cnt == 3:
                        return 'RATELIMIT'
                    
                self.alert = self.txt['snippet'].replace('&quot;', '')
                if self.alert not in self.doneAlerts and 'ALERT ON' in self.alert:
                    self.doneAlerts.append(self.alert)
                    return self.alert

            return False
        
        if account == 'b':
            
            
            self.creds = None
            if os.path.exists('tokenb.pickle'):
                # Read the token from the file and store it in the variable creds
                with open('tokenb.pickle', 'rb') as token:
                    self.creds = pickle.load(token)

            # If credentials are not available or are invalid, ask the user to log in.
            if not self.creds or not self.creds.valid:
                if self.creds and self.creds.expired and self.creds.refresh_token:
                    self.creds.refresh(Request())
                else:
                    self.flow = InstalledAppFlow.from_client_secrets_file('tokensb.json', self.SCOPES)
                    self.creds = self.flow.run_local_server(port=0)

                # Save the access token in token.pickle file for the next run
                with open('tokenb.pickle', 'wb') as token:
                    pickle.dump(self.creds, token)

            # Connect to the Gmail API
            self.service = build('gmail', 'v1', credentials=self.creds)


            # request a list of all the messages
            working = False
            cnt = 0
            while working is False:
                try:
                    self.result = self.service.users().messages().list(userId='me').execute()
                    working = True
                except Exception as exception:
                    cnt += 1
                    traceback.print_exc()
                    print('[!] rate limited.. pausing for 5')
                    time.sleep(5)
                if cnt == 2:
                    return 'RATELIMIT'


            # We can also pass maxResults to get any number of emails. Like this:
            # result = service.users().messages().list(maxResults=200, userId='me').execute()
            self.messages = self.result.get('messages')[:30][::-1]

            # messages is a list of dictionaries where each dictionary contains a message id.
            # iterate through all the messages
            for msg in self.messages:
                # Get the message from its id

                working = False
                cnt = 0
                while working is False:
                    try:
                        self.txt = self.service.users().messages().get(userId='me', id=msg['id']).execute()
                        working = True
                    except Exception as exception:
                        cnt += 1
                        traceback.print_exc()
                        print('[!] rate limited.. pausing for 5')
                        time.sleep(2)
                    if cnt == 3:
                        return 'RATELIMIT'
                
                self.alert = self.txt['snippet'].replace('&quot;', '')
                if self.alert not in self.doneAlerts and 'ALERT ON' in self.alert:
                    self.doneAlerts.append(self.alert)
                    return self.alert
                
            return False







tracker = Tracker()
signalreader = signalReader()
if data.cryptoBot:
        from bot import tradebot
        from bitrue.client import Client
        bitrueApiKey = '56a2cd362b0b99f3c51ff3ba19819a69919a291ba99eaa04e019b12f9db12dc4'
        bitrueApiSecret = '90b8ebe5984e6090ee138a84ededaf70e48f34c07d2e3c3b65892bccdf5c96ac'
        bitrue = Client(bitrueApiKey, bitrueApiSecret)
        cryptoBot = tradebot()
        cryptoBot.pushDiscordNotif('https://discord.com/api/webhooks/998947029600440442/O8HqDFNfpLpCV2SjK0KDMCo4GxxdgCTalli7d2NKtgfwx0zAStRCVpbrbMNN9PNPnFKX', type='start_msg')


waitForOneMin = False
waitForFiveMin = False
waitForFifteenMin = False
waitForThirtyMin = False
waitForOneMinReversal = False


purchased = False
purchasedPuts = False
purchasedEither = False
futurePrice = 0
boughtFuturePrice = 0

account = 'a'
first = True


try:
    oneWeek, twoWeeks, oneMonth, expirations, strike = getOptionsChain(stock='SPY', side='p', atm='2700')
except Exception as exception:
    print('[!] CAUTION. option chain retrieval test failed.')
    #traceback.print_exc()


while True:
    
    try:
        
        
        cnt = 0
        cnt_ = 0
        alert = False
        
        
        while alert is False:
            
            time.sleep(1)
            if data.cryptoBot and cryptoBot.openQT > 0:
                cnt += 1 
                if cnt == 10:
                    if cryptoBot.long: futurePrice = bitrue.get_ticker_price(symbol='ETH3LUSDT')['price']
                    if cryptoBot.short: futurePrice = bitrue.get_ticker_price(symbol='ETH3SUSDT')['price']
                    print('    | [!]                    bought price | ' + str(boughtFuturePrice))
                    print('    | [!] open ETH futures position price | ' + str(futurePrice))
                    if float(futurePrice) > float(boughtFuturePrice): addon = '+ $'
                    else: addon = '- $'
                    print('    | [!]                      DIFFERENCE | ' + addon + str(abs(float(futurePrice) - float(boughtFuturePrice))))
                    cryptoBot.logData(price=float(futurePrice))
                    cnt = 0
                    cnt_ += 1
                    if cnt_ == 12:
                        if cryptoBot.long: futurePrice = bitrue.get_ticker_price(symbol='ETH3LUSDT')['price']
                        if cryptoBot.short: futurePrice = bitrue.get_ticker_price(symbol='ETH3SUSDT')['price']
                        cryptoBot.updateMessage()
                        cnt_ = 0
                        
            if random.randint(0,2) == 1: time.sleep(1)     
            alert = signalreader.getAlert(account)            
            
            
        if alert == 'RATELIMIT':
            if account == 'a': account = 'b'
            else: account = 'a'
            continue


        ############
        # IMPORTANT : UPDATE TICKERS ON TRACKER WITH NEWEST DATA
        if not first:
            tracker.pushTicker()
        else: first = False
        ############
    
        # NOW GET DATA TO USE IN TELLING TRACKER WHICH TICKER
        # WE SHOULD LOAD FROM THEN SAVE TO
        try:
            # set variables
            alertTokens = alert.split(' ')
            if 'replacing' in alert.lower():
                alert = ' '.join(alertTokens[2:])
                alertTokens = alert.split(' ')
            ticker = alertTokens[2].lower()

        except:
            continue
        
        ############
        # IMPORTANT : UPDATE TRACKER, LOAD CORRECT INFORMATION ON TICKER
        # THIS IS SO WE ACCESS THE PROPER INFORMATION UNDER THE 
        # 'TRACKER' CLASSES PROPERTIES.
        tracker.loadTicker(ticker.lower().replace('$',''))
        ############

        conditional = alertTokens[4]
        if 'BuySig' in conditional: signal = 'buy'
        if 'SellSig' in conditional: signal = 'sell'
        value = alertTokens[8].lower()
        if value == 'false': pass
        timeframe = alertTokens[6].split(';')[1]
        currentPrice = alertTokens[20].replace(';', '')


        if '/' in ticker and data.cryptoBot and cryptoBot.openQT > 0:
            try:
                if tracker.purchased: futurePrice = bitrue.get_ticker_price(symbol='ETH3LUSDT')['price']
                if tracker.purchasedPuts: futurePrice = bitrue.get_ticker_price(symbol='ETH3SUSDT')['price']
                cryptoBot.logData(price=float(futurePrice))
                cryptoBot.updateMessage()
            except Exception as exception:
                print('######################################')
                print('cryptobot error!')
                traceback.print_exc()
               
        
        
        # SORT THROUGH DATA AND ASSIGN VARIABLES
        ##########################################
           
        if signal == 'buy' and value == 'true': side = 'c'
        if signal == 'sell' and value == 'true': side = 'p'

        if signal == 'buy' and timeframe == '1m': 
            if value == 'true': 
                tracker.oneMin = True
                tracker.oneMinSell = False 
            else: tracker.oneMin = False
        if signal == 'buy' and timeframe == '5m': 
            if value == 'true': 
                tracker.fiveMin = True     
                tracker.fiveMinSell = False
            #else: tracker.fiveMin = False
        if signal == 'buy' and timeframe == '15m': 
            if value == 'true': 
                tracker.fifteenMin = True
                tracker.fifteenMinSell = False
            #else: tracker.fifteenMin = False       
        if signal == 'buy' and timeframe == '30m': 
            if value == 'true': 
                tracker.thirtyMin = True     
                tracker.thirtyMinSell = False
            #else: tracker.thirtyMin = False
        if signal == 'buy' and timeframe == '1d': 
            if value == 'true': 
                tracker.oneDay = True    
                tracker.oneDaySell = False

            #else: tracker.oneDay = False
        if signal == 'sell' and value == 'true':
            if timeframe == '1m':
                waitForOneMin = False
                tracker.oneMin = False
                tracker.oneMinSell = True
                
            if timeframe == '5m':
                tracker.fiveMin = False
                tracker.fiveMinSell = True

            if timeframe == '15m':
                tracker.fifteenMin = False
                tracker.fifteenMinSell = True
                tracker.cond1 = False
                tracker.cond2 = False

            if timeframe == '30m':
                tracker.thirtyMin = False
                tracker.thirtyMinSell = True

            if timeframe == '1d':
                tracker.oneDay = False
                tracker.oneDaySell = True
                
        elif signal == 'sell' and value == 'false':
            if timeframe == '1m':
                tracker.oneMinSell = False
            if timeframe == '15m':
                tracker.fifteenMinSell = False
                
        if 'eth' in ticker and tracker.fiveMin and tracker.cond1 != False:
            if tracker.cond1 == 0:
                tracker.cond1 = 5
            elif tracker.cond1 == 15:
                tracker.cond1 = 20
                
        if 'eth' in ticker and tracker.fifteenMin and tracker.cond1 != False:
            if tracker.cond1 == 0:
                tracker.cond1 = 15
            elif tracker.cond1 == 5:
                tracker.cond1 = 20
                
        if 'eth' in ticker and tracker.fiveMinSell and tracker.cond2 != False:
            if tracker.cond2 == 0:
                tracker.cond2 = 5
            elif tracker.cond2 == 15:
                tracker.cond2 = 20
                
        if 'eth' in ticker and tracker.fifteenMinSell and tracker.cond2 != False:
            if tracker.cond2 == 0:
                tracker.cond2 = 15
            elif tracker.cond2 == 5:
                tracker.cond2 = 20
        
        
        # DISPLAY DATA
        ##########################################
        
        print('    |')
        print('    |                    [!] new alert recieved [!]')
        print('    |              ')
        alertText = alert[:60].replace('WHEN supertrend_().','--> ').replace('is true;','').replace('is false;','')
        if len(alertText.split(' ')[-1]) < 4: alertText = ' '.join(alertText.split(' ')[:-1])
        print('    |                ' + alertText)
        print('    |')
        print('    | TICKER       | $' + ticker.upper().replace('/',''))
        print('    | SIGNAL       | ' + signal.upper())
        print('    | value        | ' + value.upper())
        print('    | timeframe    | ' + timeframe)
        print('    | price        | ' + currentPrice)
        print('    |              |  buy  | sell ')
        print('    |      1m      | ' + str(tracker.oneMin) + '   ' + str(tracker.oneMinSell))
        print('    |      5m      | ' + str(tracker.fiveMin) + '   ' + str(tracker.fiveMinSell))
        print('    |      15m     | ' + str(tracker.fifteenMin) + '   ' + str(tracker.fifteenMinSell))
        print('    |      30m     | ' + str(tracker.thirtyMin) + '   ' + str(tracker.thirtyMinSell))
        print('    |              |')
        print('    |     cond1    | ' + str(tracker.cond1))
        print('    |     cond2    | ' + str(tracker.cond2))
    
        tickerStr = '    | '
        try:
            cnt = 0
            for x,dict in tracker.mainDict.items():
                cnt += 1
                if dict['fifteenMin'] or dict['thirtyMin'] or dict['oneDay']:
                    directionText = 'BUY'
                elif dict['fifteenMinSell'] or dict['thirtyMinSell'] or dict['oneDaySell']:
                    directionText = 'SELL'
                else:
                    directionText = 'N/A'                    
                if '/' not in x: tickerStr += '$' + x.upper() + ' - ' + directionText + ' /----\ '
                else: tickerStr += x.upper() + ' - ' + directionText + ' /----\ '
                if cnt == 3: 
                    tickerStr += '\n    | '
                    cnt = 0
            print('    |              |')
            print('    | TICKERS ---> | ' + str(len(tracker.mainDict.keys())))
            print(tickerStr)
        except Exception as exception:
            traceback.print_exc()
            pass
        
        
        # ALL TRADE CRITERIA
        ##########################################
        
        purchased = tracker.purchased
        purchasedPuts = tracker.purchasedPuts
        purchasedEither = False
        if purchased or purchasedPuts: purchasedEither = True
        else: purchasedEither = False
        
        
        
        ########################
        #### CRYPTO - ONLY ALGOS
        
        if tracker.cond1 == 20: 
            tracker.cond1 = True
            tracker.cond2 = False
            
        if tracker.cond2 == 20: 
            tracker.cond1 = False
            tracker.cond2 = True


        ##############
        # LONG SIGNAL
        
        if 'eth' in ticker.lower() and tracker.fifteenMin and not (tracker.oneMinSell or tracker.fiveMinSell or tracker.fifteenMinSell or tracker.thirtyMinSell) and not (purchased or tracker.purchased or purchasedPuts or tracker.purchasedPuts):
            tracker.purchased = True
            
            futurePrice = bitrue.get_ticker_price(symbol='ETH3LUSDT')['price']
            boughtFuturePrice = float(futurePrice)
            print('[!] ALERT: 1M / 15M crypto algo triggered')
            log(ticker, futurePrice, 'LONG', algo='1M/15M CRYPTO')
            pushDiscordNotification(ticker, 'longc', {}, {}, {}, [], 0, price=currentPrice, futurePrice=futurePrice, action='BUY')
            cryptoBot.long = True
            cryptoBot.short = False
            
            continue
        
        if 'eth' in ticker.lower() and tracker.fiveMin and not (tracker.oneMinSell or tracker.fiveMinSell or tracker.fifteenMinSell or tracker.thirtyMinSell) and not (purchased or tracker.purchased or purchasedPuts or tracker.purchasedPuts):
            tracker.purchased = True
            
            futurePrice = bitrue.get_ticker_price(symbol='ETH3LUSDT')['price']
            boughtFuturePrice = float(futurePrice)
            print('[!] ALERT: 1M / 5M crypto algo triggered')
            log(ticker, futurePrice, 'LONG', algo='5M CRYPTO')
            pushDiscordNotification(ticker, 'longc', {}, {}, {}, [], 0, price=currentPrice, futurePrice=futurePrice, action='BUY')
            cryptoBot.long = True
            cryptoBot.short = False
            
            continue
        
        if 'eth' in ticker.lower() and tracker.thirtyMin and not (tracker.oneMinSell or tracker.fiveMinSell or tracker.fifteenMinSell or tracker.thirtyMinSell) and not (purchased or tracker.purchased or purchasedPuts or tracker.purchasedPuts):
            tracker.purchased = True
            
            futurePrice = bitrue.get_ticker_price(symbol='ETH3LUSDT')['price']
            boughtFuturePrice = float(futurePrice)
            print('[!] ALERT: 30M crypto algo triggered')
            log(ticker, futurePrice, 'LONG', algo='30M CRYPTO')
            pushDiscordNotification(ticker, 'longc', {}, {}, {}, [], 0, price=currentPrice, futurePrice=futurePrice, action='BUY')
            cryptoBot.long = True
            cryptoBot.short = False
            
            continue
        
        ##############
        # CLOSE LONG SIGNAL
        
        if 'eth' in ticker.lower() and (tracker.fiveMinSell or tracker.fifteenMinSell) and (purchased or tracker.purchased):
            tracker.purchased = False
            
            futurePrice = bitrue.get_ticker_price(symbol='ETH3LUSDT')['price']
            boughtFuturePrice = 0
            print('[!] ALERT: 5M or 15M crypto sell algo triggered')
            log(ticker, futurePrice, 'SELL', algo='5M CRYPTO SELL')
            pushDiscordNotification(ticker, 'sellc', {}, {}, {}, [], 0, price=currentPrice, futurePrice=futurePrice, action='SELL')
            tracker.cond1 = 0
            tracker.cond2 = 0
            cryptoBot.long = False
            cryptoBot.short = False
        
            continue
    
        ##############
        # SHORT SIGNAL
        
        if 'eth' in ticker.lower() and tracker.oneMinSell and tracker.fifteenMinSell and not (tracker.oneMin or tracker.fiveMin or tracker.fifteenMin or tracker.thirtyMin or tracker.oneDay) and not (purchasedPuts or tracker.purchasedPuts or purchased or tracker.purchased):
            tracker.purchasedPuts = True
            
            futurePrice = bitrue.get_ticker_price(symbol='ETH3SUSDT')['price']
            boughtFuturePrice = futurePrice
            print('[!] ALERT: 1M / 15M crypto algo triggered')
            log(ticker, futurePrice, 'SHORT', algo='1M/15M CRYPTO SELL')
            pushDiscordNotification(ticker, 'p', {}, {}, {}, [], 0, price=currentPrice, futurePrice=futurePrice, action='BUY')
            cryptoBot.long = False
            cryptoBot.short = True
            
            continue
        
        if 'eth' in ticker.lower() and tracker.oneMinSell and tracker.thirtyMinSell and not (tracker.oneMin or tracker.fiveMin or tracker.fifteenMin or tracker.thirtyMin or tracker.oneDay) and not (purchasedPuts or tracker.purchasedPuts or purchased or tracker.purchased):
            tracker.purchasedPuts = True
            
            futurePrice = bitrue.get_ticker_price(symbol='ETH3SUSDT')['price']
            boughtFuturePrice = futurePrice
            print('[!] ALERT: 1M / 30M crypto algo triggered')
            log(ticker, futurePrice, 'SHORT', algo='1M/30M CRYPTO SELL')
            pushDiscordNotification(ticker, 'p', {}, {}, {}, [], 0, price=currentPrice, futurePrice=futurePrice, action='BUY')
            cryptoBot.long = False
            cryptoBot.short = True
            
            continue
        
        ##############
        # CLOSE SHORT SIGNAL
        
        if 'eth' in ticker.lower() and (tracker.fiveMin or tracker.fifteenMin) and (purchasedPuts or tracker.purchasedPuts):
            tracker.purchasedPuts = False
            
            futurePrice = bitrue.get_ticker_price(symbol='ETH3SUSDT')['price']
            boughtFuturePrice = 0
            print('[!] ALERT: 5M or 15M crypto sell algo triggered')
            log(ticker, futurePrice, 'SELL', algo='5M CRYPTO SELL')
            pushDiscordNotification(ticker, 'sellp', {}, {}, {}, [], 0, price=currentPrice, futurePrice=futurePrice, action='SELL')
            tracker.cond1 = 0
            tracker.cond2 = 0
            cryptoBot.long = False
            cryptoBot.short = False
            
            continue
        
        tracker.purchased = purchased
        tracker.purchasedPuts = purchasedPuts
        
    
    
        ########################
        #### STOCKS / UNIVERSAL ALGOS
        
        
        #####################
        ### CALLS
        
        ###############
        ### 15M / 1M CORRELATION CALL ALGO
        
        waitForOneMinReversal = tracker.cond1
        waitForOneMin = tracker.cond2
        
        if tracker.fifteenMin and tracker.oneMin and not (purchasedPuts or purchased or tracker.purchased or tracker.purchasedPuts) \
            and not tracker.thirtyMinSell and not tracker.oneDaySell:
            print('[!] ALERT: 15M / 1M algo triggered')

            log(ticker, currentPrice, 'LONG_CALL', algo='1M/15M LONG')
            tracker.cond2 = False
            tracker.cond1 = False
            if '/' not in ticker: oneWeek, twoWeeks, oneMonth, expirations, strike = getOptionsChain(stock=ticker, side='p', atm=currentPrice)
            else:
                oneWeek = {}
                twoWeeks = {}
                oneMonth = {}
                expirations = []
                strike = 0   
            tracker.purchased = True
            pushDiscordNotification(ticker, side, oneWeek, twoWeeks, oneMonth, expirations, strike, price=currentPrice, action='BUY')

            continue
            
        elif tracker.fifteenMin and tracker.oneMin and not waitForOneMinReversal and not waitForOneMin and not (purchasedPuts or purchased or tracker.purchased or tracker.purchasedPuts):
            
            waitForOneMinReversal = True
        
        elif tracker.fifteenMin and waitForOneMinReversal and tracker.oneMin is False \
            and not tracker.oneMinSell and not tracker.thirtyMinSell and not purchasedEither:
            
            waitForOneMin = True
            waitForOneMinReversal = False
            
        tracker.cond1 = waitForOneMinReversal
        tracker.cond2 = waitForOneMin    
                  
        ###############
        # 15M / 5M CORRELATION CALL ALGO  
           
        if tracker.fiveMin and tracker.fifteenMin and not tracker.thirtyMinSell and not (purchasedPuts or purchased or tracker.purchased or tracker.purchasedPuts):
            print('[!] ALERT: 1M / 5M / 15M algo triggered')

            log(ticker, currentPrice, 'LONG_CALL', algo='5M/15M LONG')
            if '/' not in ticker: oneWeek, twoWeeks, oneMonth, expirations, strike = getOptionsChain(stock=ticker, side='p', atm=currentPrice)
            else:
                oneWeek = {}
                twoWeeks = {}
                oneMonth = {}
                expirations = []
                strike = 0   
            tracker.purchased = True
            pushDiscordNotification(ticker, side, oneWeek, twoWeeks, oneMonth, expirations, strike, price=currentPrice, action='BUY')
                
            continue
        
        ###############
        # 5M / 1D CORRELATION CALL ALGO
        
        if tracker.oneDay and tracker.fiveMin and not tracker.thirtyMinSell and not (purchasedPuts or purchased or tracker.purchased or tracker.purchasedPuts):
            print('[!] ALERT: 1D / 5M algo triggered')
            
            log(ticker, currentPrice, 'LONG_CALL', algo='5M/1D LONG')  
            if '/' not in ticker: oneWeek, twoWeeks, oneMonth, expirations, strike = getOptionsChain(stock=ticker, side='p', atm=currentPrice)
            else:
                oneWeek = {}
                twoWeeks = {}
                oneMonth = {}
                expirations = []
                strike = 0      
            pushDiscordNotification(ticker, side, oneWeek, twoWeeks, oneMonth, expirations, strike, price=currentPrice, action='BUY')
            tracker.purchased = True
                

            continue

        ###############
        # CALL SELL SIGNAL    
        
        if tracker.fiveMinSell and tracker.oneMinSell and (purchased or tracker.purchased):
            
            log(ticker, currentPrice, 'SOLD_CALL', algo='5M/1M SELL')
            if '/' not in ticker: oneWeek, twoWeeks, oneMonth, expirations, strike = getOptionsChain(stock=ticker, side='p', atm=currentPrice)
            else:
                oneWeek = {}
                twoWeeks = {}
                oneMonth = {}
                expirations = []
                strike = 0            
            tracker.purchased = False
            pushDiscordNotification(ticker, 'sellc', oneWeek, twoWeeks, oneMonth, expirations, strike, price=currentPrice, action='SELL')
                

            continue
        
        
        #####################
        ### PUTS
        
        ###############
        # 15m / 1M CORRELATION PUT ALGO
        
        if tracker.fifteenMinSell and tracker.oneMinSell and not (purchasedPuts or purchased or tracker.purchasedPuts or tracker.purchased):
            print('[!] ALERT: 15m / 1M PUT algo triggered')

            log(ticker, currentPrice, 'LONG_PUT', algo='1M/15M SHORT')
            if '/' not in ticker: oneWeek, twoWeeks, oneMonth, expirations, strike = getOptionsChain(stock=ticker, side='p', atm=currentPrice)
            else:
                oneWeek = {}
                twoWeeks = {}
                oneMonth = {}
                expirations = []
                strike = 0
            pushDiscordNotification(ticker, 'p', oneWeek, twoWeeks, oneMonth, expirations, strike, price=currentPrice, action='BUY')
                

            continue
        
        ###############
        # PUT SELL SIGNAL
        
        if tracker.fiveMin and (purchasedPuts or tracker.purchasedPuts):
            
            log(ticker, currentPrice, 'SOLD_PUT', algo='5M SELL')
            oneWeek, twoWeeks, oneMonth, expirations, strike = getOptionsChain(stock=ticker, side='p', atm=currentPrice)
            tracker.purchasedPuts = False
            pushDiscordNotification(ticker, 'sellp', oneWeek, twoWeeks, oneMonth, expirations, strike, price=currentPrice, action='SELL')
                

            continue
        
        
        
        # END OF LOOP
        # TELLS TRACKER TO SAVE ALL NEW DATA ON TICKER AND WILL MAKE
        # ALL DATA ACCESS IN TRACKER BEYOND THIS POINT UNUSABLE
        # BEFORE THE TOP OF THE NEXT LOOP
        
        tracker.purchased = purchased
        tracker.purchasedPuts = purchasedPuts
        
        
        
    except Exception as exception:
    
        traceback.print_exc() 
    