#####################################################################################
# DATA FILE FOR INFINTE MONEY GLITCH.
# HERE IS WHERE YOU CONFIGURE HOW YOUR BOT HANDLES BUYING AND SELLING POSITIONS.

## !! NOTICE: FOR BOOLEAN VALUES (TRUE / FALSE), REMEMBER TO CAPITALIZE AS SUCH
#                       val = True
#                       val = False

##########################################################

# add api key
apiKey = 'AJBGODZYFXUOR5WID9IJNJCMZTDTJAAR'

# add account number
accountNumber = '253165243'

# webhook URL for discord alerts
webhookURL = 'https://discord.com/api/webhooks/966414944381833356/L83Sx8lM-pjHwi7DpM9AGkB4UZhyJ0rBP1imadyBUpr-xiHT9B7vPd6N_YDONsBZ860d'
webhooks = ['https://discord.com/api/webhooks/966414944381833356/L83Sx8lM-pjHwi7DpM9AGkB4UZhyJ0rBP1imadyBUpr-xiHT9B7vPd6N_YDONsBZ860d','https://discord.com/api/webhooks/993360499544698900/Zc36zwEEZreHu-Ar9wh1vmCgJNeiUJYuP0EYfryf3Wwd9wkK66n4kE7ordx83MCKKn50']

###########
cryptoBot = True

apiKey = '0uhvKjxgaNVQxsXcIHib8xjFS-6H5dvrt83h6GQp'

apiSecret = 'ccGQbvEBnp8QZzGfCAGnA3fttPVDfnyRTv_Q81pS'

devMode = True

############
# add discord username (without any @ or # or numbers). i.e 'xozxro'
username = '<@292425358383382529>'

# add discord channel to watch for commands to control bot
# mostly for development use, please do not touch
discordChannel = 'https://discord.com/api/v9/channels/968149876527476768/messages?limit=3'
personalAuth = 'MjkyNDI1MzU4MzgzMzgyNTI5.YkGzHQ.6s_Oihvcrjn5kDJ8Y1SjcpdePV8'

# accounts to use by identifyer
usedAccounts = ['cblast challenge', 'cblast', 'shinobisignals', 'prophitcy', 'eva', 'manz', 'bot']
# set to true / false if you want to use alerts from all accounts.
# useful for people watching and confirming trades. will overide 'usedAccounts' setting,
# so you can leave it how it is and change 'useAll' independently, keeping your settings.
useAll = False
confirmUnused = True

# previous trades to load upon startup
previousTrades = 1
# set account balance to be used here
accountBalance = 'AUTO'

# set settled cash here
# if set to 0 it will be automatically calced
# if not it will be stored alongside balance
# useful for restarts mid - day
settledCash = 0

# set max amount per trade here
amntPerTrade = 200
amntPerTradeOneCon = 300

# minimum amount of contracts
minAmount = 1

# maximum amount of contracts
maxAmount = 5

# set whether or not the bot should prompt the user before
# placing a buy order
confirmBuys = False

# set distance above and below the specified entry price
# an option can be to be purchased by the bot
# set max multiplyer
above = 3# option can be no more than 1.2x the called price

# set min
below = 0.4 # can be minimum .1x or more of the called price

# should the bot allow the user to type !confirm spy, for example, in
# order to place a trade outside of this threshold?
askToConfirm = True

# set whether account is a margin account
# if true, cash will be counted as settled cash upon exit.
# useful for sims
isMargin = False

# disable placing the orders, and force bot to assume they've
# been placed
# True disables orders / False leaves them enabled
orderDisable = False

# don't disable order - placing but force bot to assume trades
# have been placed no matter the response code from TD
assumeTradePlaced = False

# allow lotto plays?
allowLottos = False


##### ODTE SETTINGS

# include 1 dte contracts under these settings?
include1DTE = True

# MAX Amount
max0dteqt = 3

# MIN Amount
min0dteqt = 1

# 0DTE realtime price to called price threshold
ZeroDayAboveLimit = 1.04
ZeroDayBelowLimit = .98

# PLEASE SET 0DTE SIZING

# normal sizing when bot has made less than 1% on the day
ZeroDaySizingWhenNuetral = 1

# sizing when the bot is red on the day
ZeroDaySizingWhenRed = .5

# sizing when the bot is green on the day
# options
# INT/FLOAT will act as above multiplyers against the position size
# 'PROFITS' will cause bot to only buy one con if the value is less than the profits on the day
ZeroDaySizingWhenGreen = 'PROFITS'

# how to handle impossible sizing? (too little cons)
# options:
# 'ONE' will cause bot to only buy ONE unless contract price is more than the above specified sizing x your normal position sizing
# 'NONE' will cause bot to buy none when sizing multiplyer above is less than 1, and the multiplication comes out to less than 1
whenSizingImpossible = 'NONE'


# hard take profit multiplyer
# if more than 1, will take profit. if less than 1, will cut loss.
# if 0, will disable
ZeroDayHardTakeProfit = 1.2



##### LATER DAY SIZING INCREASES

# if settled cash is more then 75% the starting amount at specified time,
# multiply position size constraints by x at the specified time
positionSizingMultiplyerPast10AM = 1.2
whenBelowMultA = 1.03
positionSizingMultiplyerPast12PM = 1.2
whenBelowMultB = 1.03
positionSizingMultiplyerPast1PM = 1.3
whenBelowMultC = 1.04

#############################
#           stops           #
#############################

## !!! IMPORTANT !!!
# IT IS IMPORTANT TO UNDERSTAND HOW THE BOT TRIMS POSITIONS TO THE UPSIDE OR DOWNSIDE.
# FIRST TRIM > IF MORE THAN 4 CONTRACTS, TRIM 1/4
# SECOND TRIM > IF MORE THAN 2 CONTRACTS, TRIM 1/2
# THIRD TRIM > CUT THE REST OF THE CONTRACTS, UNLESS PLAY IS GREEN AND BOT IS SPECIFIED TO LEAVE A RUNNER.
# IF NOT HOLDING MORE THAN 2 CONTRACTS DURNIG THE FIRST OR SECOND TRIM, TRIM ALL.

# THERE ARE SOME SPECIAL CASES, SUCH AS THE MASTER STOP, TRIGGERED STOPS, AND ACCOUNT TRIGGERED STOP
# WHICH WILL SOMETIMES TRIM THE ENTIRE POSITION.


#################
# account growth target
enableGrowthTargets = True

# set TargetB to 0 if you only want to use targetA to sell all positions.
# if targetB is not set to 0, targetA will cut the specified amount from every position (cutAmount).
TargetA = 1.1
# if targetB is enabled, cut each position by what when account reaches targetA?
# 0 - 1 // i.e .5 for half, .25 for quarter, etc.
cutAmount = .5
# cut all at
TargetB = 1.2
# SET TO 0 TO DISABLE AND CUT ALL POSITIONS FULLY AFTER REACHING TARGETA

# please note that even if either target is reached, new alerts can still be bought.
# set parameters to be enacted on all new positions bought after account growth below.
# leave 0 to disable.

# size positions differently after reaching targets. available options are
# FULL / HALF / QUARTER / NONE
# FULL will maintain normal position sizing. this splits your amntPerTrade amount then calculates accordingly.
# NONE will cause the bot to stop trading after reaching the appropriate target
afterTargetAPositionSizing = 'HALF'
afterTargetBPositionSizing = 'NONE'

# set stricter stop losses
# trim or master stops will still work regardless to what this is set to, making
# its only use to enact stricter full - position stops after reaching growth target
# WILL CUT ENTIRE POSITION
afterTargetAStopLoss = .08
afterTargetBStopLoss = .05

#################
# triggered stop on entire account balance
# this is the account balance which bot will try to maintain after it is reached
# stop at accountTriggeredStop x starting balance will activate when balance
# reaches accountTrigger x starting balance.
# will cut all RED positions when balance falls under accountTriggeredStop x starting balance
# will cut ALL positions when balance continues to fall past that by ~2% or more
# default means after 25% account growth on the day, begin to cut positions after
# account balance falls below 20% account growth on the day.

accountTrigger = 1.1
accountTriggeredStop = 1.07

#################
# trailing stops to be applied to every position
# i.e. after tsTriggerPrice x price paid, cut position if price falls under the
# highest price - (tsPerc x highestPrice)
# TSperc (trailling stop percentage), is a mulitplyer that defines stop % from highest contract price
# tsPerc will adjust according to the settings below, as price meets the specified multiplyers.
# it will move up as the price moves up, and when the price meets the next multiplyer below,
# it tsPerc changed to the specified setting and the new stop price is calculated.
# once the price falls under this stop price, however high up it ends, the position will be cut.
# tsPerc CAN ONLY BE 'NEGATIVE'.
#  - NO VALUES ABOVE 1
#  - SMALLER = TIGHTER STOP FROM HIGHEST PRICE
#              !! make this tighter the higher the price
# SET TRIGGER PRICE TO 0 TO DISABLE ANY ONE

# BE CAREFUL OF CONFLICT WITH OTHER SETTINGS!

tsTriggerPriceA = 1.08
tsPercA = .06

halfSize = True
secondHalfCut = .04

tsTriggerPriceB = 1.11
tsPercB = .03

tsTriggerPriceC = 1.15
tsPercC = .04

tsTriggerPriceD = 1.21
tsPercD = .015

#################
# stop loss / trim dollar amount targets
# set dollar amount stop losses and take profit targets here
# set to 0 to disable
# please set them in order
# do not set a or b to 0 and set c to something!
# if a value is set to 0, when the bot trims at to the value before it,
# it will cut all. if the bot trims using the last stop or trim target (C),
# it will cut all. both of these are unless of course the below 'leaveRunner'
# setting is set to True

# BE CAREFUL OF CONFLICT WITH OTHER SETTINGS!

# after
cashStopLossA = 0
# dollar total loss on whole position, trim.
cashStopLossB = 0
cashStopLossC = 0

# after
cashTakeProfitA = 0
# dollar gain on whole position, trim.
cashTakeProfitB = 0
cashTakeProfitC = 0
# cut rest of position here
# unless, leave singular runner when trimming?
leaveRunner = True

# if so, hold until when?
runnerTakeProfitMultiplyer = 1.2
runnerStopLossMultiplyer = 1.035

# !! SETTING 'LEAVERUNNER' TO TRUE WILL MEAN ONE RUNNER WILL REMAIN ANY TIME THE BOT TRIMS
# FOR THE FINAL TIME, NOT JUST WHEN IT TRIMS DUE TO CASH TARGETS.

###############################################
# set whether or not the bot should only sell on exit
# alerts from sources, or also use set targets.

# !! if true, bot will ONLY sell on exit alerts from sources, as well as
#    using any settings enabled above or in the below section.
#    you can set master or trim stop losses, and a triggered stop
#    in the below section.

sellFromAlertsOnly = True # READ EVERYTHING BELOW

# THIS DICTATES WHICH SECTION OF SETTINGS BELOW THE BOT WILL USE.
# IF SET TO FALSE, PLEASE EITHER SET CASH TARGETS AND TRAILING STOPS TO
# 0, USE LESS OF THEM, AND/OR SET THEM VERY HIGH TO USE THEM IN CONJUNCTION with
# THE VALUES USED BELOW.
# !! IF YOU DONT, THEY COULD CONFLICT EASILY, AND YOU COULD END UP SELLING
# MORE OF YOUR POSITION SOONER THAN ANTICIPATED. FOR EXAMPLE, IF
# 1.2X TAKEPROFITA IS RIGHT AFTER THE FIRST DOLLAR AMOUNT TARGET YOU HAVE SET,
# THE BOT WILL TRIM TRICE AT A VERY SIMILAR PRICE.
# THE SAME GOES FOR DOWNSIDE SETTINGS.

#################
# if set to TRUE
#################
# set a MASTER STOP LOSS and TRAILING STOP targets here,
# incase an exit alert is not sent or not interpreted properly,
# and your position is not sold

#########
# CHOSE STOPS

# MASTER or TRIM
stopUsed = 'TRIM'

# MASTER SETTINGS
# default is -10% - .1
# .2 means cut FULL POSITION at -20%

masterStopLoss = .15

# OR

# TRIM  STOP SETTINGS
# first stop cuts stopQuantity x open quantity amount of contracts, second stop cuts all contracts.
# can be used in tangent with trailing stops.
# if you stop 1/2 o the position down 5%
# set your first trailling stop to trigger and cut the last half at least at a gain bringing you to break even on the whole position.
# for a first stop of -5% (.05), this would mean a trailing stop should be set at 11% with a percentage of 1%, 12% with 2%, etc.
# however, it is ideal to have one in place before that, to prevent the second half from going red a second time.
firstStop = .15
# first stop tries to sell this much of current quantity
stopQuantity = .5

# second stop sells full position
secondStop = .2

# stopQuantity is multiplied by the quantity of the position to determine how much of it to sell upon reaching the first stop.
# if this value is less than 1, set below whether the bot should sell the full position, try to sell half, or not touch it.
# (i.e trying to sell .25 of a 4 con position.)
# FULL / HALF / NONE
IfQuantityLessThanOne = 'NONE'

# ! ONLY ONE OR THE OTHER IS USED - MASTER OR TRIM!

#########
# set the green - triggered stop -- after x% green, cut all
# contracts if under y% the entry price

# BE CAREFUL OF CONFLICT WITH OTHER SETTINGS!

# after reaching
tsEnable = 1.25
# x the entry price, cut all at
tsTrigger = 1.24

# x the entry price
# can be negative too!
# i.e // .9 cuts after a 10% loss after tsEnable is reached

# !!! NOTICE: THESE VALUES ONLY WORK IF 'sellFromAlertsOnly' is set to True !!!

#################
# if set to FALSE
#################

# ATTENTION ! IT IS SUGGESTED YOU SET THESE VERY HIGH IF BEING USED WITH
# TRAILING STOPS AND / OR CASH AMOUNT TARGETS

#########
# set non - lotto stop loss and take profit targets
# ie .2 stopLoss = 20% stop loss
#    1.1 takeProfitA = 10% first trim
#    1.3 takeProfitB = 30% second trim
#    1.05 triggeredStop = full position cut at no
#    less than 5% gain after reaching the first take profit target.

# BE CAREFUL OF CONFLICT WITH OTHER SETTINGS!

# set non - lotto stop loss and take profit targets
stopLoss = 0.35
takeProfitA = 1.25
takeProfitB = 1.5
triggeredStop = 1.15

# set lotto stop loss and take profit targets
stopLossLotto = .35
takeProfitALotto = 1.2
takeProfitBLotto = 1.6
triggeredStopLotto = 1.1

#########
# set a triggered stop to be enabled after a certain % green.
# works in the same way as the green - triggered stop for alerts - only settings
# BE CAREFUL OF CONFLICT WITH OTHER SETTINGS!

# after
enableTriggeredStopAt = 1.5
# x the entry price, cut all at
triggeredStopAfterGreen = 1.5
# x the entry price

# !!! NOTICE: THESE VALUES ONLY WORK IF 'sellFromAlertsOnly' is set to False !!!
