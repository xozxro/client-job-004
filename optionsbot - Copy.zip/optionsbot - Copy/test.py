from bitrue.client import Client

bitrueApiKey = '56a2cd362b0b99f3c51ff3ba19819a69919a291ba99eaa04e019b12f9db12dc4'
bitrueApiSecret = '90b8ebe5984e6090ee138a84ededaf70e48f34c07d2e3c3b65892bccdf5c96ac'
bitrue = Client(bitrueApiKey, bitrueApiSecret)

depth = bitrue.get_ticker_price(symbol='ETH3LUSDT')


print(depth)
    