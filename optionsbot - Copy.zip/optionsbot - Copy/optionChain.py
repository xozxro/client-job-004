import json
import requests
import data
from ast import Pass
import traceback
import datetime


def getOptionsChain(stock='SPY', key='', exp='', side='', strike='', sell=False, full='', atm=''):
    if stock.lower() == 'spx.x': stock = '$spx.x'

    if '/' in stock.lower():
        return {}, {}, {}, [], 0
    base_url = 'https://api.tdameritrade.com/v1/marketdata/chains?&symbol={stock_ticker}'

    endpoint = base_url.format(stock_ticker=stock.upper())

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:77.0) Gecko/20190101 Firefox/77.0',
    }

    if side.lower() == 'c':
        side = 'c'
        type = 'CALL'
    else:
        side = 'p'
        type = 'PUT'

    # print(strike)
    # print('2022-' + exp.replace('/','-'))
    # print(type)

    try:
        page = requests.get(url=endpoint,
                            params={'apikey': 'AJBGODZYFXUOR5WID9IJNJCMZTDTJAAR'}, headers=headers)

    except:

        pass

    try:
        if type == 'PUT' or side.lower() == 'p':
            side ='p'
            chain = json.loads(page.content)
            chain = chain['putExpDateMap']

        if type == 'CALL' or side.lower() == 'c':
            side = 'c'
            chain = json.loads(page.content)
            chain = chain['callExpDateMap']
    except:
        print(page.content)
        
    # date = x.split(':')[0]
    # month = date.split('-')[1]
    # day = date.split('-')[2]

    today = datetime.datetime.now()

    oneWeek = today + datetime.timedelta(days=7)
    twoWeeks = today + datetime.timedelta(days=14)
    oneMonth = today + datetime.timedelta(days=28)

    date = str(oneWeek).split(' ')[0]
    oneWeekMonth = date.split('-')[1]
    oneWeekDay = date.split('-')[2]

    date = str(twoWeeks).split(' ')[0]
    twoWeeksMonth = date.split('-')[1]
    twoWeeksDay = date.split('-')[2]

    date = str(oneMonth).split(' ')[0]
    oneMonthMonth = date.split('-')[1]
    oneMonthDay = date.split('-')[2]

    keylist = list(chain.keys())
    
    oneWeekExp = ''

    for x, y in chain.items():

        next = keylist.index(x) + 1

        date = x.split(':')[0]
        month = date.split('-')[1]
        day = date.split('-')[2]
        
        
        if next > len(keylist):
            next = len(keylist)
        
             
        try:
            if day == oneWeekDay and oneWeekExp == '':
            
                oneWeekStrikes = y
                oneWeekExp = str(oneWeekMonth) + '/' + str(day)
                print(oneWeekExp)

            try:
                if int(day) <= int(oneWeekDay) and int(keylist[next].split(':')[0].split('-')[2]) > int(oneWeekDay) and oneWeekExp == '':
                
                    oneWeekStrikes = y
                    oneWeekExp = str(oneWeekMonth) + '/' + str(day)
                    print(oneWeekExp)  
            except:
                pass

            if (day == twoWeeksDay and month == twoWeeksMonth) or (
                    int(day) <= int(twoWeeksDay) and int(keylist[next].split(':')[0].split('-')[2]) >= int(
                    twoWeeksDay) and month == twoWeeksMonth):

                twoWeeksStrikes = y
                twoWeekExp = str(twoWeeksMonth) + '/' + str(day)

            elif (day == oneMonthDay and month == oneMonthMonth) or (
                    int(day) <= int(oneMonthDay) and int(keylist[next].split(':')[0].split('-')[2]) >= int(
                    oneMonthDay) and month == oneMonthMonth):

                oneMonthStrikes = y
                oneMonthExp = str(oneMonthMonth) + '/' + str(day)
        
        except Exception as exception:
            
            traceback.print_exc()
            
            break

    try:
        keylist = list(oneWeekStrikes.keys())
        atm = float(atm)
    except:
        return None
    
    contractStrike = float(atm)
    originalstrike = contractStrike

    for strike in oneWeekStrikes:

        next = keylist.index(strike) - 1
        if next < 0:
            lastStrike = float(strike)
        else:
            lastStrike = float(keylist[next])

        try:
            try:
                nextStrike = float(keylist[next + 2])
            except:
                try:
                    nextStrike = float(keylist[next + 1])
                except:
                    nextStrike = float(keylist[next])


            if float(strike) > float(atm) and float(lastStrike) < float(atm) and side.lower() == 'c':

                contractStrike = strike
                
                break

            elif float(strike) < float(atm) and float(nextStrike) > float(atm) and side.lower() == 'p':

                contractStrike = strike
                
                break
            
        except:
            pass
    
    
    originalStrike = contractStrike


    try:
        
        try:
            originalStrike = contractStrike
        
            oneWeekReturn = oneWeekStrikes[contractStrike][0]
            cnt = 0
            while oneWeekReturn is None:
                cnt += 1
                if side == 'c': contractStrike = float(contractStrike) + 1
                else: contractStrike = float(contractStrike) - 1
                oneWeekReturn = oneWeekStrikes[contractStrike][0]
                if cnt > 5: 
                    oneWeekReturn = {}
        except:
            oneWeekExp = '0/0'
            oneWeekStrikes = {}
            oneWeekReturn = {}

        try:
            twoWeekReturn = twoWeeksStrikes[contractStrike][0]
            cnt = 0
            while twoWeekReturn is None:
                cnt += 1
                if side == 'c': contractStrike = float(contractStrike) + 1
                else: contractStrike = float(contractStrike) - 1
                twoWeekReturn = twoWeeksStrikes[contractStrike][0]
                if cnt > 5: 
                    twoWeekReturn = {}
        except:
            twoWeekExp = '0/0'
            twoWeekStrikes = {}
            twoWeekReturn = {}
                
        try:
            oneMonthReturn = oneMonthStrikes[contractStrike][0]
            cnt = 0
            while oneMonthReturn is None:
                cnt += 1
                if side == 'c': contractStrike = float(contractStrike) + 1
                else: contractStrike = float(contractStrike) - 1
                oneMonthReturn = oneMonthStrikes[contractStrike][0]
                if cnt > 5: 
                    oneMonthReturn = {}
        except:
            oneMonthExp = '0/0'
            oneMonthStrikes = {}
            oneMonthReturn = {}
        
        
        return oneWeekReturn, twoWeekReturn, oneMonthReturn, [oneWeekExp, twoWeekExp, oneMonthExp], originalStrike
  
    except Exception as exception:
        
        try:
            test = expirations
        except:
            expirations = []

        traceback.print_exc()
        
        return {}, {}, {}, expirations, originalStrike

        




